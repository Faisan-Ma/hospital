<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Peradeniya Dentals-About-us</title>
     <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/style.css" rel="stylesheet">
	 <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
	 <link href="https://fonts.googleapis.com/css?family=Markazi+Text" rel="stylesheet">
    <script src="js/jquery-2.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

  </head>

<body>

<section id="top" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="top clearfix">
    <div class="col-sm-6 top_left clearfix">
	 <div class="top_left_inner">
	  <h5>Peradeniya Dentals Hospital</h5>
	 </div>
	</div>
	<div class="col-sm-6 top_right clearfix">
	 <div class="top_right_inner">
	  <ul>
	   <li><i class="fa fa-map-marker"></i>
Location: 494,Hospital Road,Jaffna
</li>
	   <li><i class="fa fa-phone"></i>24/7 Emergency<a href="#">  021-2227655</a></li>
	  </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="header"  class="cd-secondary-nav">
	<nav class="navbar navbar-default">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php"><span class="liner_1">Peradeniya</span><span class="liner_2">Dentals</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="" href="index.php">HOME</a>
                    </li>
                     
                    <li>
                        <a class="active_tag" href="about.php">ABOUT US</a>
                    </li>
					
					<li>
                        <a class="hvr-reveal" href="patientappointment.php">APPOINMENT</a>
                    </li>
                    <li>
                        <a class="hvr-reveal" href="contact.php.php">CONTACT US</a>
                    </li>
                    <li>
                        <a class="hvr-reveal" href="patient.php">REGISTRATION</a>
                    </li>
					
                </ul>
			
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</section>

<section id="about" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="about clearfix">
	 
	</div>
  </div>
 </div>
</section>

<section id="about_inner">
   <div class="about_inner">
     <div class="container">
	   <div class="row">
	    <div class="service_top clearfix">
	      <h2>A<span class="ready_2">BOUT </span>US</h2>
	   <div class="row">
	     <div class="col-sm-12">
		   <div class="col-sm-6">
		     <div class="about_inner_1"><img src="images/1.jpg"></div>
		   </div>
		   <div class="col-sm-6">
		     <div class="about_inner_2">
			   <h1 class="text-center">Who We Are?</h1>
			   <p class="text-center">Peradeniya_dentals has been present in SRILANKA(JAFFNA) since 1990, offering innovative solutions, specializing in medical services for treatment of medical infrastructure. With over 100 professionals actively participates in numerous initiatives aimed at creating sustainable change for patients!</p>
			 </div>
		   </div>
		 </div>
		 <div class="col-sm-12">
		   <div class="col-sm-6">
		     <div class="about_inner_2">
			   <h1 class="text-center">What Is Our Goal?</h1>
			   <p class="text-center">Our goal is to deliver quality of care in a courteous, respectful, and compassionate manner. We hope you will allow us to care for you and to be the first and best choice for healthcare.

We will work with you to develop individualised care plans, including management of chronic diseases. We are committed to being the region’s premier healthcare network providing patient centered care that inspires clinical and service excellence..</p>
			 </div>
		   </div>
		   <div class="col-sm-6">
		     <div class="about_inner_1"><img src="images/2.jpg"></div>
		   </div>		   
		 </div>
	   </div>
	 </div>
   </div>
 </section>

<section id="about_3" class="clearfix">
 <div class="main_head_3">
  <div class="container">
  <div class="row">
   <div class="about_3 clearfix">
	 <div class="about_3_inner">
	  <h4>Providing Dental Care for The Sickest In Community.</h4>
	 </div>
	 <div class="about_3_inner_2 clearfix">
	  <div class="col-sm-3"></div>
	   <div class="col-sm-2 about_3_inner_2_left clearfix">
	    <img src="images/4.jpg" >
	   </div>
	    <div class="col-sm-5 about_3_inner_2_right clearfix">
		 <div class="about_3_inner_2_right_inner">
		  <p style="color:black">We will work with you to develop individualised care plans, including management of chronic diseases. If we cannot assist, we can provide referrals or advice about the type of practitioner you require.

We are committed to being the region’s premier healthcare network by providing patient-centered care that inspires clinical and service excellence, making us the first and best choice for our patients, employees, physicians, employers, volunteers and communities. We serve the community by improving the quality of life through better health.</p>
		 </div>
		</div>
		 <div class="col-sm-2"></div>
	 </div>
	</div>
  </div>
 </div>
 </div>
</section>

<section id="about_4" class="clearfix">
  <div class="container">
  <div class="row">
   <div class="about_4 clearfix">
	 <div class="about_4_top clearfix">
	   <div class="col-sm-6 about_4_top_left clearfix">
	    <img src="images/3.jpg" width="100%">
	   </div>
	    <div class="col-sm-6 about_4_top_right clearfix">
		 <div class="about_4_top_right_inner">
		  <h4>
True Dentel care For Your Family!</h4>
		  <p>
We conduct a range of tests to help us work out why you're not feeling well and determine the right treatment for you.
Our expert doctors, nurses and allied health professionals manage patients with a broad range of medical issues.
We offer a wide range of care and support to our patients, from diagnosis to treatment and rehabilitation.</p>
		 </div>
		</div>
	 </div>
	</div>
  </div>
 </div>
</section>

<section id="about_5" class="clearfix">
 <div class="main_head_5">
  <div class="container">
  <div class="row">
   <div class="about_5 clearfix">
     <div class="col-sm-12">
	  <div class="col-sm-6">
	    <div class="about_5_inner">
		  <h1>Peradeniya_Dental has been present in Srilanka(Jaffna) since 1990, offering innovative solutions, specializing in medical services for treatment of Dental medical infrastructure. With over 100 professionals actively participates in numerous initiatives aimed at creating sustainable change for patients!</h1>
	   </div>
	  </div>
	  <div class="col-sm-6">
	   <div class="about_5_inner_1">
	    <a href="#"><img src="images/5.jpg"></a>
	   </div>
	  </div>
	 </div>	 
	</div>
  </div>
 </div>
 </div>
</section>


</section>
<section id="footer_main" class="clearfix">
	 <div class="col-sm-12 space_all">
	  <div class="footer_main_1">
	 <h2> <a href="adminlogin.php">Admin Login Panel</a> | <a href="doctorlogin.php">Doctor Login Panel</a></h2>
	    <p>© 2021 Peradeniya_Dentals. All Rights Reserved. Design by<a href="https://peradeniyadent.com/"> Y2S2G1</a> </p>
	  </div>
	 </div>
</section>

</body>
<script type="text/javascript">
	// Generated by CoffeeScript 1.7.1
$(document).ready(function() {
  $(".carousel").carousel({
    interval: 2000
  });
  $(".carousel").on("slid", function() {
    var to_slide;
    to_slide = $(".carousel-item.active").attr("data-slide-no");
    $(".myCarousel-target.active").removeClass("active");
    $(".carousel-indicators [data-slide-to=" + to_slide + "]").addClass("active");
  });
  $(".myCarousel-target").on("click", function() {
    $(this).preventDefault();
    $(".carousel").carousel(parseInt($(this).attr("data-slide-to")));
    $(".myCarousel-target.active").removeClass("active");
    $(this).addClass("active");
  });
});

	</script>      
</html>
