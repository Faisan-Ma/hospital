
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Peradeniya Dentals Patient_Home</title>
     <link href="css/bootstrap.min.css" rel="stylesheet">
     <link href="css/style.css" rel="stylesheet">
	 <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css" />
	 <link href="https://fonts.googleapis.com/css?family=Markazi+Text" rel="stylesheet">
    <script src="js/jquery-2.1.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

  </head>

<body>

<section id="top" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="top clearfix">
    <div class="col-sm-6 top_left clearfix">
	 <div class="top_left_inner">
	  <h5>Peradeniya Dentals Hospital</h5>
	 </div>
	</div>
	<div class="col-sm-6 top_right clearfix">
	 <div class="top_right_inner">
	  <ul>
	   <li><i class="fa fa-map-marker"></i>Location: 494,Hospital Road,Jaffna</li>
	   <li><i class="fa fa-phone"></i>24/7 Emergency  <a href="#"> 021-2227655</a></li>
	  </ul>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="header"  class="cd-secondary-nav">
	<nav class="navbar navbar-default">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header page-scroll">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><span class="liner_1">Peradeniya</span><span class="liner_2">Dentals</span></a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="active_tag" href="index.php">HOME</a>
                    </li>
                     
                    <li>
                        <a class="hvr-reveal" href="about.php">ABOUT US</a>
                    </li>
					
					<li>
                        <a class="hvr-reveal" href="patientappointment.php">APPOINMENT</a>
                    </li>
                    <li>
                        <a class="hvr-reveal" href="contact.php">CONTACT US</a>
                    </li>
                    <li>
                        <a class="hvr-reveal" href="patient.php">REGISTRATION</a>
                    </li>
					
                </ul>
				
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>
</section>



<section id="center_2" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="center_2 clearfix">
    <div class="center_2_top clearfix">
	 <div class="col-sm-4 center_top_left clearfix"></div>
	 <div class="col-sm-8 center_top_right clearfix">
	  <div class="cemter_top_right_inner clearfix">
	   <div class="col-sm-5 session_left clearfix"></div>
	   <div class="col-sm-7 session_right clearfix">
	    <div class="session_right_inner">
		 <h2><span class="ready_2">Dental</span>Care</h2>
	<h4>Peradeniya_Dentals Has Touched The Lives Of Patients & Providing Dental Care for The Sickest In Our Community.</h4>
<p>Peradeniya_Dental has been present in Srilanka(Jaffna) since 1990, offering innovative solutions, specializing in medical services for treatment of Dental medical infrastructure. With over 100 professionals actively participates in numerous initiatives aimed at creating sustainable change for patients!</p>
		 <h5><a href="about.php">Take More</a></h5>
		</div>
	   </div>
	  </div>
	 </div>
	</div>
	<div class="center_2_top_2 clearfix">
	 <div class="col-sm-7 center_2_top_2_left clearfix">
	  <div class="center_2_top_2_left_inner">
	   <img src="images/7.jpg" width="500">
	  </div>
	 </div>
	</div>
   </div>
  </div>
 </div>
</section>

<section id="center_3" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="center_3 clearfix">
    <div class="center_3_top clearfix">
	 <h1>Dental Care <span class="ready_2">For</span>Life</h1>
	</div>
	<div class="center_3_middle clearfix">
	 <div class="center_3_middle_head clearfix">
	   <div class="col-sm-6 center_3_middle_head_left clearfix">
	    <div class="center_3_middle_head_left_inner">
		 <div class="grid clearfix">
					<figure class="effect-oscar">
						<img src="images/3.jpg" alt="img09"/>
						<figcaption>
							<h2>Services<span>1</span></h2>
							<p>We conduct a range of tests to help us work out why you're not feeling well and determine the right treatment for you.</p>
							<a href="#">View more</a>						</figcaption>			
		  </figure>
					
	  </div>
		</div>
	   </div>
	   <div class="col-sm-6 center_3_middle_head_left clearfix">
	    <div class="center_3_middle_head_left_inner">
		 <div class="grid clearfix">
					<figure class="effect-oscar">
						<img src="images/2.jpg" alt="img09"/>
						<figcaption>
							<h2>services <span>2</span></h2>
							<p>Our expert doctors, nurses and allied health professionals manage patients with a broad range of medical issues.</p>
							<a href="#">View more</a>						</figcaption>			
		  </figure>
					
	     </div>
		</div>
	   </div>
	 </div>
   </div>
  </div>
 </div>
</section>

<section id="center_4" class="clearfix">
 <div class="center_4 clearfix">
  <div class="center_4_top clearfix">
  <div class="col-sm-8 center_4_top_inner">
    <img src="images/7.jpg" width="100%">
  </div>
  </div>
  <div class="center_4_bottom clearfix">
   <div class="center_4_bottom_inner clearfix">
   <div class="col-sm-4 center_4_bottom_inner_left clearfix"></div>
    <div class="col-sm-8 center_4_bottom_inner_right clearfix">
	 <div class="discover clearfix">
	  <h4>The Best Dental Care Clinic</h4>
	  <h2>What We Offer?</h2>
	  <h3>We offer a wide range of care and support to our patients, from diagnosis to treatment and rehabilitation.!</h3>
	  <p><a href="appointment.php">Contact us</a></p>
	 </div>
	</div>
   </div>
   <h2></h2>
  </div>
 </div>
</section>

<section id="center_5" class="clearfix">
 <div class="container">
  <div class="row">
   <div class="center_5 clearfix">
  <div class="center_5_top clearfix">
  <div class="col-sm-8 center_5_top_left clearfix">
    <div class="center_5_top_left_top clearfix">
	 <div class="col-sm-9 testing_left clearfix">
	  <div class="testing_left_inner">
	   <h3><span class="ready_3">Test</span>imonials</h3>
	 <p>2 months ago
I had some issues with my teeth for a decade. I  consulted  different doctors but nothing felt good. Now I feel complete satisfaction with the treatment in MS clinic.
Prescription of medicines and care after surgery is very good.</p>
	   <h2>Archana Sekaran</h2>
	   <h5>Srilanla</h5>
	  </div>
	 </div>
	</div>
  </div>
  </div>
  <div class="center_5_bottom clearfix">
   <div class="center_5_bottom_inner clearfix">
   <div class="col-sm-4 center_5_bottom_inner_left clearfix"></div>
    <div class="col-sm-8 center_5_bottom_inner_right clearfix">
	 <div class="paitent clearfix"><br><br><br><br><br><br>
	  <img src="images/8.jpg"  style="transform:translate(40%,20%);width:60%">
	 </div>
	</div>
   </div>
   <h2></h2>
  </div>
 </div>
  </div>
 </div>
</section>




<section id="footer_main" class="clearfix">
	 <div class="col-sm-12 space_all">
	  <div class="footer_main_1">
	  <h4> <a href="adminlogin.php">Admin Login Panel</a> | <a href="doctorlogin.php">Doctor Login Panel</a></h4>
	    <p>© 2021 Peradeniya Dentals. All Rights Reserved. Design by<a href=https://peradeniyadent.com/"> Y2S2G1</a> </p>
	  </div>
	 </div>
</section>
</body>
<script type="text/javascript">
	// Generated by CoffeeScript 1.7.1
$(document).ready(function() {
  $(".carousel").carousel({
    interval: 2000
  });
  $(".carousel").on("slid", function() {
    var to_slide;
    to_slide = $(".carousel-item.active").attr("data-slide-no");
    $(".myCarousel-target.active").removeClass("active");
    $(".carousel-indicators [data-slide-to=" + to_slide + "]").addClass("active");
  });
  $(".myCarousel-target").on("click", function() {
    $(this).preventDefault();
    $(".carousel").carousel(parseInt($(this).attr("data-slide-to")));
    $(".myCarousel-target.active").removeClass("active");
    $(this).addClass("active");
  });
});

	</script>      
</html>
